class CreatePatients < ActiveRecord::Migration[6.1]
  def change
    create_table :patients do |t|
      t.string :patientname
      t.integer :age
      t.text :address
      t.text :reason
      t.date :joindate
      t.string :medision
      t.date :dischargedate

      t.timestamps
    end
  end
end
