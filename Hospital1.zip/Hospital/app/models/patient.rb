class Patient < ApplicationRecord
    belongs_to :user
    validates :patientname, length: {minimum:2, maximum:20}
    validates :age, length: {minimum:2, maximum:3}
    validates :address, length: {minimum:5, maximum:100}
    validates :reason, length: {minimum:2, maximum:100}
    validates :medision, length: {minimum:2, maximum:100}
    
end
